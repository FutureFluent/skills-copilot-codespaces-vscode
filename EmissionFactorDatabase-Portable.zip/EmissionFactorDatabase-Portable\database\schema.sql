-- ============================================================================
-- EMISSION FACTOR DATABASE - Complete Schema
-- ============================================================================
-- Version: 2.0
-- Database: PostgreSQL 12+
-- Compatible with: Supabase, Neon, AWS RDS, Google Cloud SQL, Azure Database
--
-- This schema creates all tables needed for the emission factor matching system
-- ============================================================================

-- ============================================================================
-- TABLE: emission_factors
-- Main table containing ~44,000 country-specific emission factors
-- ============================================================================

CREATE TABLE IF NOT EXISTS emission_factors (
  -- Primary key
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Classification
  nace_code TEXT,                                    -- NACE Rev. 2 code (e.g., "35.11")
  category TEXT NOT NULL,                            -- High-level category (e.g., "Electricity & Gas")
  subcategory TEXT,                                  -- Subcategory (e.g., "Electricity by wind")

  -- Exiobase product mapping
  exiobase_product_code TEXT,                        -- Exiobase code (e.g., "p40.11.e")
  exiobase_product_name TEXT,                        -- Product name (e.g., "Electricity by wind")

  -- Country specificity
  country_code TEXT,                                 -- ISO2 country code (e.g., "SE")
  country_name TEXT,                                 -- Country name (e.g., "Sweden")

  -- Emission factors
  emission_factor_kgco2e_per_eur NUMERIC NOT NULL,  -- Main factor (kg CO2e per EUR)
  emission_factor_kgco2e_per_unit NUMERIC,          -- Optional: per physical unit
  physical_unit TEXT,                                -- Unit (e.g., "kWh", "kg")

  -- Metadata
  scope TEXT CHECK (scope IN ('scope1', 'scope2', 'scope3')),
  region TEXT,                                       -- Region code (e.g., "EU", "SE", "RoW")
  data_source TEXT DEFAULT 'EXIOBASE_3.9.6_IOT_2022',
  source_year INTEGER DEFAULT 2022,
  confidence_level TEXT CHECK (confidence_level IN ('high', 'medium', 'low')) DEFAULT 'medium',

  -- Statistics (from Exiobase)
  total_output_eur NUMERIC,                          -- Total economic output
  num_countries INTEGER,                             -- Number of countries in aggregation

  -- Additional metadata (JSON)
  metadata JSONB,

  -- Status
  is_active BOOLEAN DEFAULT true,

  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- TABLE: nace_emission_factors
-- Aggregated NACE-level emission factors (fallback for Tier 4)
-- ============================================================================

CREATE TABLE IF NOT EXISTS nace_emission_factors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- NACE classification
  nace_code TEXT NOT NULL UNIQUE,
  nace_description TEXT,

  -- Emission factors by scope
  scope_1_factor NUMERIC,           -- Direct emissions
  scope_2_factor NUMERIC,           -- Purchased electricity/heat
  scope_3_factor NUMERIC,           -- Supply chain emissions

  -- Metadata
  source TEXT,
  source_year INTEGER DEFAULT 2022,
  confidence_level TEXT CHECK (confidence_level IN ('high', 'medium', 'low')),
  total_output_eur NUMERIC,
  num_countries INTEGER,

  -- Exiobase product mapping
  exiobase_sectors JSONB,

  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- TABLE: supplier_nace_mappings
-- Learning system for supplier → NACE code mappings
-- ============================================================================

CREATE TABLE IF NOT EXISTS supplier_nace_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Supplier identification
  supplier_name_normalized TEXT NOT NULL UNIQUE,    -- Normalized name (lowercase, no suffixes)
  vat_number TEXT,                                  -- Optional VAT number
  country_code TEXT,                                -- Supplier country

  -- NACE mapping
  nace_code TEXT NOT NULL,

  -- Confidence and learning
  confidence_score NUMERIC DEFAULT 1.0 CHECK (confidence_score >= 0 AND confidence_score <= 1),
  source TEXT CHECK (source IN ('vat_lookup', 'manual', 'ai_suggested', 'crowd_sourced', 'user_verified')),
  times_used INTEGER DEFAULT 0,

  -- Verification
  verified_by TEXT,                                 -- User ID who verified
  verified_at TIMESTAMPTZ,

  -- Multi-tenancy (optional)
  company_id TEXT,

  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- TABLE: vat_cache
-- Cache for VAT number lookups (24-hour TTL)
-- ============================================================================

CREATE TABLE IF NOT EXISTS vat_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- VAT information
  vat_number TEXT NOT NULL UNIQUE,
  country_code TEXT,
  company_name TEXT,
  nace_code TEXT,

  -- Validation
  is_valid BOOLEAN DEFAULT true,
  validation_date TIMESTAMPTZ,

  -- Cache control
  cached_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '24 hours'),

  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- TABLE: emission_category_mappings
-- Company-specific account code → NACE/emission factor mappings
-- ============================================================================

CREATE TABLE IF NOT EXISTS emission_category_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Company context
  company_id TEXT NOT NULL,

  -- Account mapping
  account_code TEXT NOT NULL,
  account_name TEXT,

  -- Emission mapping
  nace_code TEXT,
  emission_factor_id UUID REFERENCES emission_factors(id),
  category TEXT,

  -- Metadata
  notes TEXT,
  created_by TEXT,

  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Unique constraint: one mapping per company per account
  UNIQUE(company_id, account_code)
);

-- ============================================================================
-- INDEXES for Performance
-- ============================================================================

-- emission_factors indexes
CREATE INDEX IF NOT EXISTS idx_ef_nace ON emission_factors(nace_code);
CREATE INDEX IF NOT EXISTS idx_ef_category ON emission_factors(category);
CREATE INDEX IF NOT EXISTS idx_ef_scope ON emission_factors(scope);
CREATE INDEX IF NOT EXISTS idx_ef_region ON emission_factors(region);
CREATE INDEX IF NOT EXISTS idx_ef_active ON emission_factors(is_active);
CREATE INDEX IF NOT EXISTS idx_ef_exiobase_product ON emission_factors(exiobase_product_code);
CREATE INDEX IF NOT EXISTS idx_ef_country_code ON emission_factors(country_code);
CREATE INDEX IF NOT EXISTS idx_ef_nace_country ON emission_factors(nace_code, country_code);
CREATE INDEX IF NOT EXISTS idx_ef_nace_product_country ON emission_factors(nace_code, exiobase_product_code, country_code);

-- Unique constraint for country-specific emission factors
CREATE UNIQUE INDEX IF NOT EXISTS idx_ef_unique_nace_product_country
ON emission_factors(nace_code, exiobase_product_code, country_code)
WHERE nace_code IS NOT NULL
  AND exiobase_product_code IS NOT NULL
  AND country_code IS NOT NULL;

-- nace_emission_factors indexes
CREATE INDEX IF NOT EXISTS idx_nace_ef_code ON nace_emission_factors(nace_code);

-- supplier_nace_mappings indexes
CREATE INDEX IF NOT EXISTS idx_supplier_normalized ON supplier_nace_mappings(supplier_name_normalized);
CREATE INDEX IF NOT EXISTS idx_supplier_nace ON supplier_nace_mappings(nace_code);
CREATE INDEX IF NOT EXISTS idx_supplier_vat ON supplier_nace_mappings(vat_number);
CREATE INDEX IF NOT EXISTS idx_supplier_confidence ON supplier_nace_mappings(confidence_score DESC);

-- vat_cache indexes
CREATE INDEX IF NOT EXISTS idx_vat_number ON vat_cache(vat_number);
CREATE INDEX IF NOT EXISTS idx_vat_expires ON vat_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_vat_valid ON vat_cache(is_valid) WHERE is_valid = true;

-- emission_category_mappings indexes
CREATE INDEX IF NOT EXISTS idx_ecm_company ON emission_category_mappings(company_id);
CREATE INDEX IF NOT EXISTS idx_ecm_account ON emission_category_mappings(account_code);
CREATE INDEX IF NOT EXISTS idx_ecm_nace ON emission_category_mappings(nace_code);
CREATE INDEX IF NOT EXISTS idx_ecm_company_account ON emission_category_mappings(company_id, account_code);

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Function: Update updated_at timestamp automatically
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function: Normalize supplier name
CREATE OR REPLACE FUNCTION normalize_supplier_name(name TEXT)
RETURNS TEXT AS $$
BEGIN
  RETURN trim(regexp_replace(lower(name), '\s*(ab|oy|as|gmbh|ltd|llc|inc|corp|sa|srl|bv|ag|nv|bhd|sdn|pte)\s*$', '', 'gi'));
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Function: Increment supplier usage counter
CREATE OR REPLACE FUNCTION increment_supplier_usage(supplier_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE supplier_nace_mappings
  SET times_used = times_used + 1,
      updated_at = now()
  WHERE id = supplier_id;
END;
$$ LANGUAGE plpgsql;

-- Function: Clean expired VAT cache entries
CREATE OR REPLACE FUNCTION clean_expired_vat_cache()
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM vat_cache
  WHERE expires_at < now();

  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Trigger: Auto-update updated_at on emission_factors
DROP TRIGGER IF EXISTS update_emission_factors_updated_at ON emission_factors;
CREATE TRIGGER update_emission_factors_updated_at
  BEFORE UPDATE ON emission_factors
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger: Auto-update updated_at on nace_emission_factors
DROP TRIGGER IF EXISTS update_nace_emission_factors_updated_at ON nace_emission_factors;
CREATE TRIGGER update_nace_emission_factors_updated_at
  BEFORE UPDATE ON nace_emission_factors
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger: Auto-update updated_at on supplier_nace_mappings
DROP TRIGGER IF EXISTS update_supplier_nace_mappings_updated_at ON supplier_nace_mappings;
CREATE TRIGGER update_supplier_nace_mappings_updated_at
  BEFORE UPDATE ON supplier_nace_mappings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger: Auto-update updated_at on vat_cache
DROP TRIGGER IF EXISTS update_vat_cache_updated_at ON vat_cache;
CREATE TRIGGER update_vat_cache_updated_at
  BEFORE UPDATE ON vat_cache
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger: Auto-update updated_at on emission_category_mappings
DROP TRIGGER IF EXISTS update_emission_category_mappings_updated_at ON emission_category_mappings;
CREATE TRIGGER update_emission_category_mappings_updated_at
  BEFORE UPDATE ON emission_category_mappings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- COMMENTS (Table and Column Documentation)
-- ============================================================================

COMMENT ON TABLE emission_factors IS 'Country-specific emission factors from Exiobase 3.9.6 (product × country combinations, ~44,000 rows)';
COMMENT ON COLUMN emission_factors.nace_code IS 'NACE Rev. 2 economic activity code';
COMMENT ON COLUMN emission_factors.exiobase_product_code IS 'Exiobase product code (e.g., p40.11.e for wind electricity)';
COMMENT ON COLUMN emission_factors.country_code IS 'ISO2 country code (e.g., SE for Sweden)';
COMMENT ON COLUMN emission_factors.emission_factor_kgco2e_per_eur IS 'Emission factor in kg CO2e per EUR spent';

COMMENT ON TABLE nace_emission_factors IS 'Aggregated NACE-level emission factors (global averages, used as Tier 4 fallback)';

COMMENT ON TABLE supplier_nace_mappings IS 'Learning system: Supplier name → NACE code mappings (improves over time)';
COMMENT ON COLUMN supplier_nace_mappings.supplier_name_normalized IS 'Normalized supplier name (lowercase, company suffixes removed)';
COMMENT ON COLUMN supplier_nace_mappings.confidence_score IS 'Confidence score 0-1 (1.0 = user verified, 0.8 = AI suggested)';
COMMENT ON COLUMN supplier_nace_mappings.times_used IS 'Usage counter for reinforcement learning';

COMMENT ON TABLE vat_cache IS 'VAT number lookup cache (24-hour TTL, auto-expires)';
COMMENT ON COLUMN vat_cache.expires_at IS 'Cache expiry timestamp (24 hours from cached_at)';

COMMENT ON TABLE emission_category_mappings IS 'Company-specific account code mappings for automatic emission factor assignment';

-- ============================================================================
-- INITIAL DATA (Optional Seed Data)
-- ============================================================================

-- Example: Insert EU average emission factors for common categories
-- These serve as Tier 4 fallbacks if no detailed data is available

INSERT INTO nace_emission_factors (nace_code, nace_description, scope_3_factor, confidence_level, source)
VALUES
  ('35.11', 'Production of electricity', 0.250, 'medium', 'EXIOBASE_3.9.6_EU_AVERAGE'),
  ('35.21', 'Manufacture of gas', 0.300, 'medium', 'EXIOBASE_3.9.6_EU_AVERAGE'),
  ('49.39', 'Other passenger land transport', 0.150, 'medium', 'EXIOBASE_3.9.6_EU_AVERAGE'),
  ('55.10', 'Hotels and similar accommodation', 0.120, 'medium', 'EXIOBASE_3.9.6_EU_AVERAGE'),
  ('74.90', 'Other professional, scientific and technical activities', 0.080, 'low', 'EXIOBASE_3.9.6_EU_AVERAGE')
ON CONFLICT (nace_code) DO NOTHING;

-- ============================================================================
-- MAINTENANCE TASKS (Optional - Set up as cron jobs)
-- ============================================================================

-- Clean expired VAT cache entries daily
-- Example cron (if using pg_cron extension):
-- SELECT cron.schedule('clean-vat-cache', '0 2 * * *', 'SELECT clean_expired_vat_cache()');

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- After import, verify data:

-- Check emission factors count
-- SELECT COUNT(*) FROM emission_factors;
-- Expected: ~44,394

-- Check country coverage
-- SELECT COUNT(DISTINCT country_code) FROM emission_factors;
-- Expected: 49

-- Check NACE coverage
-- SELECT COUNT(DISTINCT nace_code) FROM emission_factors;
-- Expected: 44-906

-- Sample data check
-- SELECT nace_code, country_code, exiobase_product_name, emission_factor_kgco2e_per_eur
-- FROM emission_factors
-- WHERE nace_code = '35.11'
-- ORDER BY emission_factor_kgco2e_per_eur
-- LIMIT 10;
-- Expected: Should show low-emission countries (SE, NO, FR) at top

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
